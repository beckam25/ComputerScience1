"""
file: dlList.py
language: python3
author: bre5933@rit.edu Brian R Eckam
description:
Has the double linked list class
"""

from dlNode import *

class double_linked_lst(struct):
    """double linked list class"""
    _slots = (((NoneType, Node), 'head'), (int, 'size'), ((NoneType, Node), 'cursor'))


def create_lst():
    """creates an empty double linked list"""
    return double_linked_lst(None, 0, None)


def add_element(lst, element):
    """
    adds the element to the list
    :param lst: current list
    :param element: element to add to list
    """
    my_input = Node(element, None, None)
    if lst.size == 0:
        lst.head = my_input
        lst.head.next = my_input
        lst.head.prev = my_input
    else:
        lst.head.prev.next = my_input
        my_input.prev = lst.head.prev
        lst.head.prev = my_input
        my_input.next = lst.head
    lst.size += 1

def delete_element_clockwise(lst):
    """
    deletes the head of the list
    :param lst: list of players
    """
    if lst.size == 1:
        raise IndexError("The list size is 1")
    lst.head.prev.next = lst.head.next
    lst.head.next.prev = lst.head.prev
    lst.head = lst.head.next
    lst.size -= 1

def delete_element_counter(lst):
    """
    deletes the head of the list
    :param lst: list of players
    """
    if lst.size == 1:
        raise IndexError("The list size is 1")
    lst.head.prev.next = lst.head.next
    lst.head.next.prev = lst.head.prev
    lst.head = lst.head.prev
    lst.size -= 1

def move_clockwise(lst):
    """
    passes the "potato" clockwise
    :param lst: the list of players
    """
    lst.head = lst.head.next

def move_counter(lst):
    """
    passes the "potato" counter clockwise
    :param lst: the list of players
    """
    lst.head = lst.head.prev

def get_data(lst):
    """
    gets the player name from the head of the list
    :param lst: the list of players
    :return: data of head of list
    """
    return lst.head.data

