"""
file: potato.py
language: python3
author: bre5933@rit.edu Brian R Eckam
description:
A game of 'hot potato' is played with a list of players
that are read from a file. The person with the potato is OUT
and passes in the same direction as before they were out.
The last person in the game WINS!

"""
from dlList import *
import random

def random_seed(value):
    """gets the random seed value"""
    random.seed(value)

def game(lst):
    """
    This is the main game function. A random number is picked based on the
    current list size and is passed either clockwise or counter
    clockwise based on whether it is positive or negative.
    Once the list is cycled x amount of times the new head is deleted from the list.
    :param lst: the list of players
    """
    x = random.randint(-2*lst.size,2*lst.size)
    print("The music starts ("+str(x)+")")
    passes = get_data(lst)
    if x >= 0:
        while x > 0:
            move_clockwise(lst)
            passes += " -> " + get_data(lst) # every iteration adds the next player to hold the potato
            x -= 1
        delete_element_clockwise(lst)

    if x < 0:
        while x < 0:
            move_counter(lst)
            passes += " -> " + get_data(lst) # every iteration adds the next player to hold the potato
            x += 1
        delete_element_counter(lst)
    print(passes,"is stuck holding the potato!")


def lets_play(lst):
    """
    The game is played until the list size is 1
    :param lst: list of players
    """
    while lst.size > 1:
        game(lst)
    print(get_data(lst),"is the winner!")

def read_file(file):
    """
    reads the file and prints the names of the players
    :param file: file to be read
    :return: list of players
    """
    x = create_lst()
    for line in open(file):
        line = line.strip()
        add_element(x,line)
    return x


def main():
    """
    The main function which prompts the user for file and seed value
    Then runs the game with that file.
    """
    print("Welcome to the Hot Potato Game!")
    file = input("input a file of contestants: ")
    y = input("Enter a seed number: ")
    random_seed(y)
    print("Ready to play Hot Potato. Contestants are: ")
    x = read_file(file)
    names_string = ''
    for i in range(x.size):
        names_string += get_data(x) + ' '
        move_clockwise(x)
    print(names_string)
    lets_play(x)

main()