"""
file: dlNode.py
language: python3
author: bre5933@rit.edu Brian R Eckam
description:
Has the Double Linked Node class

"""

from rit_lib import *

class Node(struct):
    """ Double linked Node class"""
    _slots = ((object, 'data'), ((NoneType, 'Node'), 'next'), ((NoneType, 'Node'), 'prev'))