"""
file: lru.py
language: python3
author: bre5933@rit.edu Brian R Eckam
description:
This program simulates a cache replacement algorithm. It identifies
the "victim" in a full cache and replaces the victim with the current
memory page being accessed.
"""
from rit_lib import *


class LRUEntry(struct):
    """
    creates a class called LRUEntry
    """
    _slots = ((str, 'page'), (int, 'time'))


def put_in_cache(entry, cache):
    """
    installs the entry into the first empty location in the cache
    :param entry: the character to be processed
    :param cache: the LRUEntry information
    :return: index of the entry in the cache
    """
    for index in range(len(cache)):
        if cache[index] == None:
            cache[index] = entry
            return index


def position_in_cache(request, cache):
    """
    finds the position of the request character in the cache
    :param request: the item searched for in the cache
    :param cache: LRUEntry information
    :return: index of request if in the cache
    returns length of cache if request is not present
    """
    for index in range(len(cache)):
        if cache[index] == None:
            return len(cache)
        elif cache[index].page == request:
            return index
    return len(cache)


def find_LRU(cache):
    """
    find and return the least recently used cache item
    :param cache: LRUEnrtry information
    :return: least recently used entry and index of that entry
    """
    min_time = cache[0].time  # default min time to first time in cache
    location = 0  # initialize location
    for index in range(len(cache)):  # for each index in cache
        if cache[index].time < min_time:  # if time @ index is less than min_time
            min_time = cache[index].time  # the time at index is the new min_time
            location = index  #
    return (cache[location], location)


def run_LRU(cache, requests):
    """
    implements LRU algorithm on the memory request string
    :param cache: LRU algorithm information
    :param requests: string of memory requests
    :return: count of misses
    """
    time = 0
    miss = 0
    for i in requests:  # for each character in requests
        if None in cache:  # if there is a None in the cache
            if position_in_cache(i, cache) < len(cache):  # if character is in cache
                print("Time: ", time, "Request: ", i, " HIT.")
                cache[position_in_cache(i, cache)].time = time
            else:
                miss = miss + 1
                put_in_cache(LRUEntry(i, time), cache)  # put an LRUEntry in the cache
                print("Time: ", time, "Request: ", i, " MISS. Victim: _  Cache: ", cache)
        else:  # no None, cache full
            if position_in_cache(i, cache) < len(cache):
                print("Time: ", time, "Request: ", i, " HIT.")
                cache[position_in_cache(i, cache)].time = time
            else:
                miss = miss + 1
                x = find_LRU(cache)  # tuple of least recently used data
                cache[x[1]] = LRUEntry(i, time)  # put new data in least recently used
                print("Time: ", time, "Request: ", i, " MISS. Victim:", x[0], "Cache: ", cache)
        time = time + 1
    return miss


def main():
    """
    main() takes a user input cache size and sequence of memory requests
    and sends the cache and memory to the LRU algorithm to be processed.
    It also prints the title of the algorithm, size and sequence as well
    as the return value of run_LRU = misses
    """
    size = int(input("Enter cache size: "))
    sequence = input("Enter memory sequence: ")
    print("Least Recently Used (LRU) Algorithm")
    print("Cache size:", size)
    print("Memory request string: ", sequence)
    cache = []
    while size > 0:
        cache = cache + [None]
        size = size - 1
    print("Miss Count: ", run_LRU(cache, sequence))


main()
