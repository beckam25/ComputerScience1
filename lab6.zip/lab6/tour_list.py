from tour_utils import *


def main():
    """
    takes a list of locations and draws it with a turtle
    """
    tour = file_lst()
    turtle_setup()
    turtle.up()
    total_distance = 0
    count = 0
    visit_lst = [tour[0].name]
    path = ""
    for place in tour:
        turtle.goto(place.x, place.y)
        turtle.down()
        turtle.dot()
        x = (round(place.x * 100) / 100)
        y = (round(place.y * 100) / 100)
        turtle.write(place.name + str('( ') + str(x) + str(' , ') + str(y) + str(' )'))
        if count > 0:
            total_distance += distance(tour[count - 1].x, tour[count - 1].y, tour[count].x, tour[count].y)
            count = count + 1
            visit_lst = visit_lst + [tour[count - 1].name]
        else:
            count = count + 1
    for letter in visit_lst:
        path = path + letter + str(" => ")
    turtle.goto(tour[0].x, tour[0].y)
    path = path + tour[0].name
    total_distance += distance(tour[0].x, tour[0].y, tour[count - 1].x, tour[count - 1].y)
    print(path)
    print("Distance:", total_distance)
    print("Close the canvas window to Quit.")
    turtle.done()


main()
