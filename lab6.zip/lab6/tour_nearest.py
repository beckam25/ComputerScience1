from tour_utils import *


def nearest():
    """
    takes a random list and reorders the list based on the minimum distance
    between the elements in the list.
    calculates the next nearest neighbor
    :return: ordered list of nearest elements
    """
    tour_lst = file_lst()
    turtle_setup()
    new_lst = [tour_lst[0]]
    current_place = tour_lst[0]
    tour_lst = tour_lst[1:]  # gets rid of first element
    while len(tour_lst) > 0:
        closest = tour_lst[0]  # keep track of the place object
        current_distance = distance(current_place.x, current_place.y, closest.x, closest.y)
        for element in tour_lst:  # element is a place object
            if distance(current_place.x, current_place.y, element.x, element.y) < current_distance:
                current_distance = distance(current_place.x, current_place.y, element.x, element.y)
                closest = element  # element is the new closest
        new_lst.append(closest)
        tour_lst.remove(closest)
        current_place = closest
    return new_lst


def main():
    """
    takes the nearest  neighbor list and draws it with a turtle
    """
    cache = nearest()
    turtle.up()
    total_distance = 0
    count = 0
    visit_lst = [cache[0].name]
    path = ""
    for place in cache:
        turtle.goto(place.x, place.y)
        turtle.dot()
        x = (round(place.x * 100) / 100)
        y = (round(place.y * 100) / 100)
        turtle.write(place.name + str('( ') + str(x) + str(' , ') + str(y) + str(' )'))
        turtle.down()
        if count > 0:
            total_distance += distance(cache[count - 1].x, cache[count - 1].y, cache[count].x, cache[count].y)
            count = count + 1
            visit_lst = visit_lst + [cache[count - 1].name]
        else:
            count = count + 1
    for letter in visit_lst:
        path = path + letter + str(" => ")
    turtle.goto(cache[0].x, cache[0].y)
    path = path + cache[0].name
    total_distance += distance(cache[0].x, cache[0].y, cache[count - 1].x, cache[count - 1].y)
    print(path)
    print("Distance:", total_distance)
    print("Close the canvas window to Quit.")
    turtle.done()


main()
