import math
from rit_lib import *
import turtle


def turtle_setup():
    """
    sets up the turtle window
    """
    turtle.setworldcoordinates(0, 0, 1000, 1000)
    turtle.setup(600, 600)


def file_lst():
    """
    takes a file and creates a list of locations based on the class place
    :return: list of locations with x,y coordinates
    """
    print("+++++++++++++++++++++++++++++++++++++++++++++++++")
    print("Welcome to the Dippy Hippie Tour. Get on the bus!")
    print("+++++++++++++++++++++++++++++++++++++++++++++++++")
    filename = input("Enter filename: ")
    text = open(filename)
    lst = []
    count = 0
    for line in text:
        count = count + 1
        stripped = line.split(',')
        x = place(stripped[0], float(stripped[1]), float(stripped[2]))
        lst = lst + [x]
    print("Reading", filename, "...", count, "places")
    return lst


class place(struct):
    """
    class called place with three a tuple of three types.
    """
    _slots = ((str, 'name'), (float, 'x'), (float, 'y'))


def distance(x1, y1, x2, y2):
    """
    compute the distance between two points
    :param x1: x value of first place
    :param y1: y value of first place
    :param x2: x value of second place
    :param y2: y value of second place
    :return: distance between point 1 and point 2
    """
    x = x2 - x1
    y = y2 - y1
    d = math.sqrt(x ** 2 + y ** 2)
    return d
