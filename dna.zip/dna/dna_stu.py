"""
Program with three basic DNA functions that are used in
conjunction with a test function for homework.

File: dna_stu.py
Author: Aaron Deever
Author: Brian Eckam
"""

from slList_stu import *

def constructDnaList(dnaString):
    """
    Given a DNA string, converts it into a list in which
    each character is a node.
    :param dnaString: string of DNA
    :return: dna string as a list
    """
    x = createList()
    for each in dnaString:
        append(x,each)
    return x


def convertDnaListToString(lst):
    """
    Given a dna string in list form, convert back to string
    :param lst: dna list
    :return: dna as string
    """
    x = ''
    cursor = lst.head
    for each in range(lst.size):
        x = x + cursor.data
        cursor = cursor.next
    return x



def isPairing(lst1, lst2):
    """
    tests if the two strings are dna complementary base pairs.
    A must match with T, G with C.  Strings must be same length too.
    :param lst1: first dna list
    :param lst2: second dna list
    :return: boolean True if match, False else
    """
    if lst1.size != lst2.size:
        return False

    x = lst1.head
    y = lst2.head
    for each in range(lst1.size):
        if (x.data == 'T' and y.data == 'A') or (x.data == 'A' and y.data == 'T') or \
                (x.data == 'G' and y.data == 'C') or (x.data == 'C' and y.data == 'G'):
            x = x.next
            y = y.next
        else:
            return False

    return True


    # PUT YOUR IMPLEMENTATION HERE